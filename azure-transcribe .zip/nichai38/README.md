# NICHAI-38 音声文字起こしツール（Azure Speech）

HTML＋CSS＋JS の単一HTML（`dist/transcribe.html`）と `dist/config.js` の2ファイルだけで動きます。

## 使い方（Windows × VSCode × Docker）
1. Docker Desktop（WSL2）と VSCode の拡張「Dev Containers」を入れる
2. このフォルダを **WSL のファイルシステム内**に置いて VSCode で開く
3. 「コンテナーで再度開く」（メモリ4GB制限つき＝低スペックPCの再現）
4. `npm test` … 単体テスト＋モック結合テスト（課金0円）
5. `npm run dev` … ビルド＋モック起動（ポート8787は自動転送）
6. `dist/transcribe.html` を **Windows側の Chrome / Edge** で開く（初期の config.js はモック向け）

## 実Azureで試す（L1→L2→L3）
1. `dist/` を Windows の別フォルダにコピー
2. `config.sample.js` を `dist/config.js` として置き、接続先とAPIキーを書く
3. 10〜30秒の音声で試す ← **ここでCORSが通るかが分かる（最優先）**
4. 通れば数分の音声、最後に3時間を1回だけ

## 構成
- `spec.md` 仕様書（正）／`CLAUDE.md` AIへの指示／`docs/modification.md` 改修方法
- `src/core` 純粋関数（分割・WAV・再試行・結合・エラー文言）
- `src/pipeline.js` 分割→送信→結合（画面に依存しない）
- `src/azure.js` ファスト・トランスクリプション呼び出し
- `src/app.js` 画面 / `build.mjs` 単一HTML化 / `mock/` モック

## 未検証（要・実機確認）
- ローカルHTMLから実Azureへの通信（CORS）
- M4A・AACの実ファイルでの切り出し品質（M4Aは16kHzモノラルに展開する方式。100MBまで）
- MP3の境目の品質、3時間ファイルのメモリ推移（確認A）
- ファスト・トランスクリプションのAPI版（config の apiVersion）とDXBEでの上限
