/**
 * 【要点】画面の配線だけを行う。処理の本体は pipeline.js。
 *  - ここにロジックを増やさない（テストしにくくなる）。
 *  - 状態は3つだけ: file（選んだ音声）/ running（処理中）/ text（結果）
 *  - sync() が、状態に合わせてボタンの有効・無効を決める。
 *    処理中は開始・選択・分割変更を押せなくして、二重実行を防ぐ。 (U-04)
 *  - 設定は window.APP_CONFIG（config.js が先に読み込まれて作る）。
 */
import { transcribeFile } from "./pipeline.js";
import { AppError, describeError } from "./core/errorMessages.js";

const $ = (id) => document.getElementById(id);
const cfg = window.APP_CONFIG;
let file = null, running = false, text = "";

const showError = (m) => { $("error").textContent = m; $("error").hidden = !m; };
const sync = () => {
  $("start").disabled = !file || running;
  $("pick").disabled = running; $("chunk").disabled = running;
  $("save").disabled = !text;
};

// 音声の長さだけを <audio> のメタデータから取得する（全体は展開しないので軽い）。失敗したら NaN
const getDuration = (f) => new Promise((resolve) => {
  const a = new Audio(), url = URL.createObjectURL(f);
  const done = (v) => { URL.revokeObjectURL(url); resolve(v); };
  a.preload = "metadata"; a.onloadedmetadata = () => done(a.duration); a.onerror = () => done(NaN);
  setTimeout(() => done(NaN), 15000); a.src = url;
});

// M4A等: 16kHzモノラルのPCMへ展開する。★メモリを大きく使う（pipeline側でサイズ上限を確認済み）
//  - AudioContext に sampleRate:16000 を指定すると、展開と同時に16kHzへ変換される
//  - ステレオは左右を平均してモノラルに、Float32(-1〜1) を Int16 に変換（WAVの標準形式）
async function decodeToPcm16k(f) {
  const ctx = new AudioContext({ sampleRate: 16000 });
  try {
    const buf = await ctx.decodeAudioData(await f.arrayBuffer());
    const ch = buf.numberOfChannels, n = buf.length, out = new Int16Array(n);
    const data = Array.from({ length: ch }, (_, i) => buf.getChannelData(i));
    for (let i = 0; i < n; i++) {
      let s = 0; for (let c = 0; c < ch; c++) s += data[c][i];
      out[i] = Math.max(-1, Math.min(1, s / ch)) * 32767;
    }
    return out;
  } finally { ctx.close(); }
}

function init() {
  // config.js が無い・中身が空なら、処理を始めずに原因と対処を表示する
  if (!cfg || !cfg.speechEndpoint || !cfg.speechKey) { showError(describeError(new AppError("CONFIG"))); return; }
  const sel = $("chunk");
  [1, 5, 10, 15, 20, 30].forEach((m) => sel.add(new Option(`${m} 分ごと`, m, false, m === cfg.defaultChunkMinutes)));
  $("pick").onclick = () => $("file").click();
  $("file").onchange = (e) => {
    file = e.target.files[0] || null; text = ""; $("result").value = ""; showError("");
    $("fileName").textContent = file ? `${file.name}（${(file.size / 1048576).toFixed(1)} MB）` : "ファイルが選ばれていません";
    $("status").textContent = "待機中"; sync();
  };
  // 「文字起こし開始」: 準備→処理（進捗を画面へ）→完了、失敗なら原因と対処を表示。最後は必ず running を戻す
  $("start").onclick = async () => {
    running = true; text = ""; $("result").value = ""; showError(""); sync();
    $("status").textContent = "準備中です…";
    try {
      text = await transcribeFile(file, cfg, {
        chunkMin: Number(sel.value),
        onProgress: ({ done, total }) => {
          $("progress").max = total; $("progress").value = done;
          $("status").textContent = done < total ? `${done + 1} / ${total} 区間を処理中` : `${total} / ${total} 区間 完了`;
        },
        onStatus: (m) => ($("status").textContent = m),
      }, { getDuration, decodeToPcm16k });
      $("result").value = text;
      $("status").textContent = "完了しました。内容を確認して、必要なら .txt で保存できます。";
    } catch (e) { showError(describeError(e)); $("status").textContent = "停止しました"; }
    running = false; sync();
  };
  // .txt保存: 結果を Blob にして <a download> でダウンロード。ファイル名は元の音声名.txt（UTF-8）
  $("save").onclick = () => {
    const a = document.createElement("a");
    a.href = URL.createObjectURL(new Blob([text], { type: "text/plain;charset=utf-8" }));
    a.download = (file ? file.name.replace(/\.[^.]+$/, "") : "result") + ".txt";
    a.click(); URL.revokeObjectURL(a.href);
  };
}
init();
