/**
 * 【要点】失敗しても、待ってから自動でやり直す。 (X-02/F-09)
 *  - 対象: 429（混雑）、5xx（Azure側の一時障害）、通信失敗。
 *  - 401（キー誤り）や404は、何度やっても直らないので再試行しない。
 *  - 待ち時間は 1秒 → 2秒 → 4秒 と倍々に伸ばす（Azureを急かさない。公式も推奨）。
 *  - sleep を外から差し替えられるので、テストは待たずに一瞬で終わる。
 */
const defaultRetryable = (e) => e.network || [429, 500, 502, 503, 504].includes(e.status);

export async function withRetry(fn, opts = {}) {
  const { max = 3, baseMs = 1000, sleep = (ms) => new Promise((r) => setTimeout(r, ms)),
    isRetryable = defaultRetryable, onRetry = () => {} } = opts;
  for (let attempt = 0; ; attempt++) {
    try { return await fn(attempt); }
    catch (e) {
      if (attempt >= max || !isRetryable(e)) throw e; // 回数切れ、または直らない種類のエラー → 呼び出し元へ
      onRetry(attempt + 1, e);
      await sleep(baseMs * 2 ** attempt);
    }
  }
}
