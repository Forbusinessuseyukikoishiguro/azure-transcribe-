/**
 * 【要点】区間ごとの結果をつなぎ合わせる。 (F-05)
 * results は { 区間番号: 文字列 } の形。番号の小さい順に並べるので、
 * 結果が届いた順序が前後しても、文章の順番は必ず正しくなる。
 * 空の区間（無音など）は捨て、区間の間は空行1つで区切る。
 */
export function joinResults(results) {
  return Object.keys(results).map(Number).sort((a, b) => a - b)
    .map((i) => results[i].trim()).filter(Boolean).join("\n\n");
}
