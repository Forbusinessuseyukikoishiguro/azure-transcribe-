/**
 * 【要点】音声の全体の長さ(秒)を、chunkMin 分ごとの「区間」に分ける計画表を作る。 (F-03/F-04)
 *  - 音声データには触れず、数字だけを扱う純粋関数。ブラウザなしでテストできる。
 *  - 例: 180分 ÷ 10分 → 18区間 [{index:0, startSec:0, endSec:600}, ...]
 *  - 割り切れない端数は最後の区間が短くなる（185分 → 19区間、最後は5分）。
 *  - chunkMin は小数可（テストでは 0.1分 = 6秒 を使い、短い音声で複数区間を作る）。
 */
export function planChunks({ totalSec, chunkMin }) {
  const size = Math.max(1, chunkMin * 60); // 1秒未満だと区間が増えすぎるため、最低1秒にする
  const plan = [];
  for (let s = 0, i = 0; s < totalSec; s += size, i++) {
    plan.push({ index: i, startSec: s, endSec: Math.min(s + size, totalSec) });
  }
  return plan;
}

/**
 * 【要点】1区間のファイルサイズが maxMB を超えないよう、区間の長さを自動で短くする。 (T-02/03)
 *  - 理由: 44.1kHzステレオWAVは3時間で約1.9GB。10分ごとでも1区間が約100MBになり、
 *    メモリにもAzureの上限にも厳しい。利用者に意識させず、内部で短くする。
 *  - 例: 1.9GB・3時間・50MB上限 → 約 28 秒ごとに分割される
 */
export function effectiveChunkSec(sizeBytes, totalSec, chunkSec, maxMB) {
  const bytesPerSec = sizeBytes / totalSec;            // このファイルの平均的な重さ（バイト/秒）
  const limitSec = (maxMB * 1024 * 1024) / bytesPerSec; // 上限サイズに収まる最大の秒数
  return Math.max(1, Math.min(chunkSec, Math.floor(limitSec)));
}
