/**
 * 【要点】WAVファイルを「バイト位置で切る」ための部品。
 *
 * WAV の中身（RIFF形式）はこう並んでいる:
 *   [RIFF ヘッダー 12バイト] [fmt チャンク: 形式情報] [data チャンク: 生の音データ] ...
 *   形式情報 = チャンネル数 / サンプルレート / 1秒あたりのバイト数(byteRate) など
 * 音データは圧縮されていないので「時間 × byteRate = バイト位置」で正確に切れる。
 * 切った後は、区間ごとに新しい44バイトのヘッダーを付ければ、それだけで正しいWAVになる。
 * → ファイル全体をメモリに展開せずに済む（低メモリPC対応の核心）。
 */
const tag = (u8, o) => String.fromCharCode(u8[o], u8[o + 1], u8[o + 2], u8[o + 3]);

// ヘッダーを読んで { 形式, チャンネル数, byteRate, 音データの開始位置, 音データの長さ } を返す。
// WAVでなければ null。引数は先頭64KB程度で足りる（全体を読む必要はない）。
export function parseWav(u8) {
  if (u8.length < 12 || tag(u8, 0) !== "RIFF" || tag(u8, 8) !== "WAVE") return null;
  const dv = new DataView(u8.buffer, u8.byteOffset, u8.byteLength);
  let p = 12, fmt = null;
  while (p + 8 <= u8.length) { // チャンクを順にたどる。各チャンク = 4文字の名前 + 4バイトの長さ + 中身
    const id = tag(u8, p), size = dv.getUint32(p + 4, true);
    if (id === "fmt ") {
      fmt = {
        format: dv.getUint16(p + 8, true), channels: dv.getUint16(p + 10, true),
        sampleRate: dv.getUint32(p + 12, true), byteRate: dv.getUint32(p + 16, true),
        blockAlign: dv.getUint16(p + 20, true), bits: dv.getUint16(p + 22, true),
      };
    } else if (id === "data") {
      return fmt ? { ...fmt, dataStart: p + 8, dataSize: size } : null;
    }
    p += 8 + size + (size % 2); // 次のチャンクへ。奇数長の場合は1バイトの詰め物がある
  }
  return null;
}

// 区間用の44バイトのヘッダーを作る（PCM固定）。dataSize はその区間の音データのバイト数。
// 最後の setUint32(40, dataSize) が「この後に続く音データの長さ」。
export function buildWavHeader({ channels, sampleRate, bits, dataSize }) {
  const blockAlign = (channels * bits) / 8;
  const h = new DataView(new ArrayBuffer(44));
  const w = (o, s) => [...s].forEach((c, i) => h.setUint8(o + i, c.charCodeAt(0)));
  w(0, "RIFF"); h.setUint32(4, 36 + dataSize, true); w(8, "WAVE"); w(12, "fmt ");
  h.setUint32(16, 16, true); h.setUint16(20, 1, true); h.setUint16(22, channels, true);
  h.setUint32(24, sampleRate, true); h.setUint32(28, sampleRate * blockAlign, true);
  h.setUint16(32, blockAlign, true); h.setUint16(34, bits, true);
  w(36, "data"); h.setUint32(40, dataSize, true);
  return new Uint8Array(h.buffer);
}

/**
 * 【要点】MP3 / AAC は「フレーム」という小さな単位の連続でできている。
 * 各フレームの先頭には 0xFF で始まる印（同期ワード）がある。
 * バイト位置で適当に切ると、フレームの途中で切れて音が壊れるため、
 * 切りたい位置の「直後のフレーム先頭」を探して、そこで切る。
 * 見つからなければ -1。
 *  - mp3: 2バイト目の上位3ビットが全部1、バージョン・レイヤーが予約値でないこと
 *  - aac: ADTS形式の印（0xFFF + レイヤー00）
 */
export function findFrameSync(u8, kind) {
  for (let i = 0; i < u8.length - 1; i++) {
    if (u8[i] !== 0xff) continue;
    const b = u8[i + 1];
    if (kind === "mp3" && (b & 0xe0) === 0xe0 && ((b >> 3) & 3) !== 1 && ((b >> 1) & 3) !== 0) return i;
    if (kind === "aac" && (b & 0xf6) === 0xf0) return i;
  }
  return -1;
}
