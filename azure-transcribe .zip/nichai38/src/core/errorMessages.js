/**
 * 【要点】利用者に見せるエラー文言は、ここだけに書く。 (F-09)
 * 必ず「何が起きたか（原因）」と「次に何をすればよいか（対処）」の2点セットにする。
 *  悪い例: 「401」「Failed to fetch」  ／  よい例: 「認証に失敗しました。APIキーを確認してください」
 * 内部で投げるエラーは AppError(code) か、HTTP状態(status)・通信失敗(network)を持つ Error。
 * 区間の途中で失敗したときは、pipeline.js が e.detail.chunk に区間情報を付けるので、
 * 「7番目の区間（60分00秒〜70分00秒）で失敗しました。」と先頭に付けられる。
 */
export class AppError extends Error {
  constructor(code, detail = {}) { super(code); this.code = code; this.detail = detail; }
}
const mmss = (s) => `${Math.floor(s / 60)}分${String(Math.floor(s % 60)).padStart(2, "0")}秒`;

export function describeError(e) {
  const where = e.detail?.chunk
    ? `${e.detail.chunk.index + 1}番目の区間（${mmss(e.detail.chunk.startSec)}〜${mmss(e.detail.chunk.endSec)}）で失敗しました。` : "";
  if (e.code === "UNSUPPORTED") return `この形式（${e.detail.ext}）には対応していません。MP3 または WAV に変換してから、もう一度お試しください。`;
  if (e.code === "TOO_BIG_TO_DECODE") return "このファイルはこの形式のまま処理するには大きすぎます。MP3 または WAV に変換してから、もう一度お試しください。";
  if (e.code === "CONFIG") return "設定が読み込めません。config.js が同じフォルダにあり、接続先とAPIキーが書かれているか確認してください。";
  if (e.network) return `${where}Azure に接続できませんでした。ネットワーク接続と、config.js の接続先を確認してください。`;
  if (e.status === 401 || e.status === 403) return `${where}認証に失敗しました。config.js のAPIキーが正しいか確認してください。`;
  if (e.status === 404) return `${where}接続先が見つかりません。config.js の接続先とAPI版を確認してください。`;
  if (e.status === 429) return `${where}Azure が混雑しています。しばらく待ってから、もう一度お試しください。`;
  if (e.status) return `${where}Azure からエラー（${e.status}）が返りました。時間をおいて再実行するか、分割の長さを短くしてみてください。`;
  return `${where}予期しないエラーが起きました：${e.message}`;
}
