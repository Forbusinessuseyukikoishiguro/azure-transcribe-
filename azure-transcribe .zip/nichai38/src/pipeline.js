/**
 * 【要点】このツールの心臓部。ボタン1回で「分割 → 送信 → 結合」を自動で行う。 (F-02〜F-05)
 *
 * 全体の流れ（transcribeFile）:
 *   1. openSource  … 形式を判定し、「秒で指定すると、その区間の音声(Blob)を返す関数 slice」を用意する
 *   2. effectiveChunkSec / planChunks … 区間の計画表を作る
 *   3. 区間を1つずつ順番に: slice → Azureへ送信（失敗したら再試行）→ 結果を番号つきで保管
 *   4. joinResults … 番号順に結合して返す
 *
 * 低メモリの工夫:
 *   - ファイルは丸ごと読まない。Blob.slice は「範囲の指定」だけで、読むのは必要な部分だけ。
 *   - 区間は1つずつ。送り終えたら参照を残さない（ガベージコレクションで解放される）。
 * 画面（DOM）に依存しないので、Node.js でもテストできる。
 */
import { planChunks, effectiveChunkSec } from "./core/planChunks.js";
import { parseWav, buildWavHeader, findFrameSync } from "./core/wav.js";
import { withRetry } from "./core/retry.js";
import { joinResults } from "./core/joinResults.js";
import { AppError } from "./core/errorMessages.js";
import { transcribeBlob } from "./azure.js";

const extOf = (name) => (name.split(".").pop() || "").toLowerCase();

// 形式ごとに「全体の長さ(totalSec)」と「区間の取り出し関数(slice)」を用意する。
// 戻り値: { totalSec, name: 送るときのファイル名, slice(開始秒, 終了秒) → Blob }
async function openSource(file, cfg, deps) {
  const ext = extOf(file.name);
  // ① WAV(PCM): いちばん簡単。時間×byteRate でバイト位置が決まり、新ヘッダーを付ければ完成
  if (ext === "wav") {
    const w = parseWav(new Uint8Array(await file.slice(0, 65536).arrayBuffer()));
    if (w && w.format === 1 && w.byteRate > 0) {
      const dataSize = Math.min(w.dataSize, file.size - w.dataStart); // 録音が途中で切れたファイルでも、実際のサイズに合わせる
      return {
        totalSec: dataSize / w.byteRate, name: "chunk.wav",
        slice: (a, b) => {
          // 切る位置は blockAlign（1サンプル分のバイト数）の倍数にそろえる。ずれると雑音になる
          const align = (t) => Math.floor((t * w.byteRate) / w.blockAlign) * w.blockAlign;
          const s = align(a), e = Math.min(align(b), dataSize);
          const header = buildWavHeader({ ...w, dataSize: e - s });
          return new Blob([header, file.slice(w.dataStart + s, w.dataStart + e)], { type: "audio/wav" });
        },
      };
    }
  }
  // ② MP3/AAC: 圧縮されたまま切る。長さは <audio> のメタデータから取得（全体は展開しない）
  if (ext === "mp3" || ext === "aac") {
    const totalSec = await deps.getDuration?.(file);
    if (Number.isFinite(totalSec) && totalSec > 0) {
      // ※可変ビットレート(VBR)の長い録音は、割合での位置推定が少しずれることがある【要検証】
      const at = async (sec) => { // 秒→おおよそのバイト位置→直後のフレーム先頭に合わせる
        if (sec >= totalSec) return file.size;
        const guess = Math.floor((file.size * sec) / totalSec);
        if (guess <= 0) return 0;
        const win = new Uint8Array(await file.slice(guess, guess + 8192).arrayBuffer());
        const k = findFrameSync(win, ext);
        return k < 0 ? guess : guess + k;
      };
      return {
        totalSec, name: `chunk.${ext}`,
        slice: async (a, b) => file.slice(await at(a), await at(b), ext === "mp3" ? "audio/mpeg" : "audio/aac"),
      };
    }
  }
  // ③ M4A・その他: 構造上、単純に切れない。ブラウザで一度「16kHzモノラル」に展開してから切る。
  //    展開すると大きくふくらむ（3時間で約350MB〜700MB）ので、maxDecodeMB を超えるファイルは断る。
  if (file.size > cfg.maxDecodeMB * 1024 * 1024) throw new AppError("TOO_BIG_TO_DECODE", { ext });
  if (!deps.decodeToPcm16k) throw new AppError("UNSUPPORTED", { ext });
  let pcm;
  try { pcm = await deps.decodeToPcm16k(file); } catch { throw new AppError("UNSUPPORTED", { ext }); }
  return {
    totalSec: pcm.length / 16000, name: "chunk.wav",
    slice: (a, b) => {
      const part = pcm.subarray(Math.floor(a * 16000), Math.min(Math.floor(b * 16000), pcm.length));
      const header = buildWavHeader({ channels: 1, sampleRate: 16000, bits: 16, dataSize: part.length * 2 });
      return new Blob([header, part], { type: "audio/wav" });
    },
  };
}

// 利用者が押す「文字起こし開始」の中身。戻り値は結合済みの全文。
//  hooks: chunkMin=分割(分) / onProgress=進捗通知 / onStatus=状況の文字 / signal=中止用
//  deps : 画面側の機能を外から渡す（getDuration, decodeToPcm16k）。テストでは偽物を渡す
export async function transcribeFile(file, cfg, { chunkMin, onProgress = () => {}, onStatus = () => {}, signal } = {}, deps = {}) {
  const src = await openSource(file, cfg, deps);
  const sec = effectiveChunkSec(file.size, src.totalSec, (chunkMin || cfg.defaultChunkMinutes) * 60, cfg.maxChunkMB);
  const plan = planChunks({ totalSec: src.totalSec, chunkMin: sec / 60 });
  const results = {};
  onProgress({ done: 0, total: plan.length });
  for (const c of plan) { // 1区間ずつ順番に。同時に送らない（Azureの混雑制限とPC負荷を避けるため）
    if (signal?.aborted) throw new DOMException("aborted", "AbortError");
    try {
      results[c.index] = await withRetry(async () => {
        const blob = await src.slice(c.startSec, c.endSec); // 送信後は参照を残さない
        return transcribeBlob({ blob, filename: src.name, cfg, fetchImpl: deps.fetchImpl, signal });
      }, { max: cfg.maxRetries, baseMs: deps.baseMs ?? 1000, sleep: deps.sleep,
           onRetry: (n) => onStatus(`${c.index + 1}番目の区間を再試行しています（${n}回目）`) });
    } catch (e) {
      e.detail = { ...(e.detail || {}), chunk: c }; throw e; // 何番目の区間で失敗したかを付けて、画面のエラー文に使う
    }
    onProgress({ done: c.index + 1, total: plan.length });
  }
  return joinResults(results);
}
