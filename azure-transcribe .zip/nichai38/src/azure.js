/**
 * 【要点】1区間分の音声を Azure に送り、文字を受け取る。 (F-06)
 *  - 使う窓口: ファスト・トランスクリプション（ファイルを送ると短時間で結果が返る）
 *  - 送り方: multipart/form-data。 audio = 区間の音声、 definition = 設定(JSON、言語など)
 *  - 認証: ヘッダー Ocp-Apim-Subscription-Key にAPIキー（config.js から）
 *  - ★ローカルHTMLから直接呼べるか（CORS）は、公式に記載がなく【要検証】。
 *    ブラウザが拒否すると fetch は TypeError になるので、下で network エラーに変換している。
 *  - fetchImpl を差し替えられる設計 → テストではモックや偽fetchを使える（課金0円）。
 */
export async function transcribeBlob({ blob, filename, cfg, fetchImpl = fetch, signal }) {
  const url = `${cfg.speechEndpoint.replace(/\/+$/, "")}/speechtotext/transcriptions:transcribe?api-version=${cfg.apiVersion}`;
  const form = new FormData(); // Content-Type は付けない（ブラウザが境界文字列つきで自動設定する）
  form.append("audio", blob, filename);
  form.append("definition", JSON.stringify({ locales: [cfg.locale || "ja-JP"] }));
  let res;
  try {
    res = await fetchImpl(url, { method: "POST", headers: { "Ocp-Apim-Subscription-Key": cfg.speechKey }, body: form, signal });
  } catch (e) {
    if (e.name === "AbortError") throw e; // 利用者の中止は、通信失敗として扱わない
    const err = new Error("network"); err.network = true; throw err;
  }
  if (!res.ok) { // 401/429/500 など。status を持たせると、再試行の判定と文言選びに使える
    const err = new Error(`HTTP ${res.status}`); err.status = res.status; throw err; }
  const json = await res.json();
  // 結果の取り出し: combinedPhrases は全文をまとめたもの。なければ phrases（細かい区切り）をつなぐ
  if (json.combinedPhrases?.length) return json.combinedPhrases.map((p) => p.text).join("\n");
  return (json.phrases || []).map((p) => p.text).join("");
}
