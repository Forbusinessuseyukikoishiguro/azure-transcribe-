import { describe, it, expect, beforeAll, afterAll } from "vitest";
import { createMock } from "../mock/mock-server.js";
import { transcribeFile } from "../src/pipeline.js";
import { buildWavHeader, parseWav } from "../src/core/wav.js";

const wavFile = (sec, rate = 8000) => {
  const data = new Uint8Array(sec * rate * 2);
  return new File([buildWavHeader({ channels: 1, sampleRate: rate, bits: 16, dataSize: data.length }), data], "t.wav");
};
let mock, cfg;
beforeAll(async () => {
  mock = createMock({ delayMs: 1 });
  await new Promise((r) => mock.server.listen(0, r));
  cfg = { speechEndpoint: `http://localhost:${mock.server.address().port}`, speechKey: "k", apiVersion: "2024-11-15",
    locale: "ja-JP", defaultChunkMinutes: 10, maxChunkMB: 50, maxRetries: 3, maxDecodeMB: 100 };
});
afterAll(() => mock.server.close());

describe("F-05 ボタン1回で分割→送信→結合（L0）", () => {
  it("30秒を0.1分(6秒)ごと→5区間、番号順に結合", async () => {
    mock.calls.length = 0;
    const prog = [];
    const out = await transcribeFile(wavFile(30), cfg, { chunkMin: 0.1, onProgress: (p) => prog.push(p.done) });
    expect(mock.calls).toHaveLength(5);
    expect(out.split("\n\n")).toEqual([1, 2, 3, 4, 5].map((n) => `（モック）${n}番目の結果`));
    expect(prog).toEqual([0, 1, 2, 3, 4, 5]);
  });
  it("各区間は有効なWAVで、サイズは 44 + 6秒分", async () => {
    let sizes = [];
    const fetchImpl = async (url, init) => { sizes.push(init.body.get("audio").size); return new Response(JSON.stringify({ combinedPhrases: [{ text: "x" }] })); };
    await transcribeFile(wavFile(12), cfg, { chunkMin: 0.1 }, { fetchImpl });
    expect(sizes).toEqual([44 + 96000, 44 + 96000]);
  });
  it("429が出ても再試行して最後まで完了する（X-02）", async () => {
    let n = 0;
    const fetchImpl = async () => (n++ % 2 === 0 ? new Response("{}", { status: 429 }) : new Response(JSON.stringify({ combinedPhrases: [{ text: "ok" }] })));
    const out = await transcribeFile(wavFile(12), cfg, { chunkMin: 0.1 }, { fetchImpl, sleep: async () => {} });
    expect(out).toBe("ok\n\nok");
  });
  it("401は区間番号つきで止まる", async () => {
    const fetchImpl = async () => new Response("{}", { status: 401 });
    await expect(transcribeFile(wavFile(12), cfg, { chunkMin: 0.1 }, { fetchImpl })).rejects.toMatchObject({ status: 401, detail: { chunk: { index: 0 } } });
  });
  it("未対応形式は分かりやすいエラー", async () => {
    await expect(transcribeFile(new File([new Uint8Array(10)], "a.ogg"), cfg, {}, {})).rejects.toMatchObject({ code: "UNSUPPORTED" });
  });
});
