import { describe, it, expect, vi } from "vitest";
import { planChunks, effectiveChunkSec } from "../src/core/planChunks.js";
import { withRetry } from "../src/core/retry.js";
import { joinResults } from "../src/core/joinResults.js";
import { parseWav, buildWavHeader, findFrameSync } from "../src/core/wav.js";
import { describeError, AppError } from "../src/core/errorMessages.js";

describe("F-03/F-04 分割計画", () => {
  it("180分を10分ごとで18区間、30分で6区間", () => {
    expect(planChunks({ totalSec: 10800, chunkMin: 10 })).toHaveLength(18);
    expect(planChunks({ totalSec: 10800, chunkMin: 30 })).toHaveLength(6);
  });
  it("端数は最後の区間に入る", () => {
    const p = planChunks({ totalSec: 11100, chunkMin: 10 });
    expect(p).toHaveLength(19); expect(p.at(-1).endSec - p.at(-1).startSec).toBe(300);
  });
  it("T-02 サイズ上限を超えるなら区間を自動で短くする", () => {
    // 3時間 1.9GB（WAV 44.1kHz stereo）→ 50MB上限
    expect(effectiveChunkSec(1.9e9, 10800, 600, 50)).toBeLessThan(600);
    expect(effectiveChunkSec(173e6, 10800, 600, 50)).toBe(600);
  });
});
describe("F-09 再試行", () => {
  it("429は待って再試行し、成功すれば結果を返す", async () => {
    const sleep = vi.fn().mockResolvedValue();
    let n = 0;
    const r = await withRetry(async () => { if (n++ < 2) throw Object.assign(new Error(), { status: 429 }); return "ok"; }, { max: 3, sleep });
    expect(r).toBe("ok"); expect(sleep.mock.calls.map((c) => c[0])).toEqual([1000, 2000]);
  });
  it("上限を超えたら投げる／401は再試行しない", async () => {
    const sleep = vi.fn().mockResolvedValue();
    await expect(withRetry(() => Promise.reject(Object.assign(new Error(), { status: 429 })), { max: 2, sleep })).rejects.toBeTruthy();
    expect(sleep).toHaveBeenCalledTimes(2);
    const s2 = vi.fn();
    await expect(withRetry(() => Promise.reject(Object.assign(new Error(), { status: 401 })), { sleep: s2 })).rejects.toBeTruthy();
    expect(s2).not.toHaveBeenCalled();
  });
});
describe("F-05 結合", () => {
  it("到着順が前後しても区間番号順", () => {
    expect(joinResults({ 2: "C", 0: "A", 1: " B " })).toBe("A\n\nB\n\nC");
  });
});
describe("WAV / フレーム同期", () => {
  it("ヘッダーを作って読み戻せる", () => {
    const h = buildWavHeader({ channels: 1, sampleRate: 16000, bits: 16, dataSize: 3200 });
    const w = parseWav(h);
    expect(w).toMatchObject({ format: 1, channels: 1, sampleRate: 16000, byteRate: 32000, dataStart: 44, dataSize: 3200 });
  });
  it("MP3/AACの同期ワードを見つける", () => {
    expect(findFrameSync(new Uint8Array([0, 0, 0xff, 0xfb, 0x90]), "mp3")).toBe(2);
    expect(findFrameSync(new Uint8Array([1, 0xff, 0xf1, 0x50]), "aac")).toBe(1);
    expect(findFrameSync(new Uint8Array([1, 2, 3]), "mp3")).toBe(-1);
  });
});
describe("4.4.3 エラー文言（原因＋対処）", () => {
  it("401・通信失敗・未対応形式・区間番号", () => {
    expect(describeError(Object.assign(new Error(), { status: 401 }))).toContain("APIキー");
    expect(describeError(Object.assign(new Error(), { network: true }))).toContain("接続先");
    expect(describeError(new AppError("UNSUPPORTED", { ext: "ogg" }))).toContain("MP3 または WAV");
    const e = Object.assign(new Error(), { status: 500, detail: { chunk: { index: 6, startSec: 3600, endSec: 4200 } } });
    expect(describeError(e)).toContain("7番目の区間（60分00秒〜70分00秒）");
  });
});
