// 【要点】環境ごとに書き換えるのは、このファイルだけ（HTML本体は触らない）。
// <script src="config.js"> で読まれ、window.APP_CONFIG として HTML 側から参照される。
// なぜ config.json ではなく .js か: file:// で開いたHTMLは、ブラウザの制限で別ファイルを fetch できないが、
// <script> での読み込みは許可されるため。
// ★キーはテキストで読める。配布先の限定・キーの入れ替え・Azure側の予算アラートで守ること。
window.APP_CONFIG = {
  speechEndpoint: "https://＜リソース名＞.cognitiveservices.azure.com", // 接続先
  speechKey: "＜ここにAPIキー＞",   // 合言葉。他人に見せない・コミットしない
  apiVersion: "2024-11-15",          // ファスト・トランスクリプションのAPI版
  locale: "ja-JP",                   // 音声の言語
  defaultChunkMinutes: 10,           // 分割の初期値（分）
  maxChunkMB: 50,                    // 1区間の最大サイズ。超えたら自動で短くする
  maxRetries: 3,                     // 失敗時の再試行回数
  maxDecodeMB: 100                   // M4A等を展開する場合の最大ファイルサイズ
};
