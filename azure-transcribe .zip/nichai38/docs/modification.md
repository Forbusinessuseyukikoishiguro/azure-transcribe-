# 改修方法

## 1. 基本の流れ（どの改修でも同じ）
```
① 何を変えたいか決める
② spec.md を直す（要件ID・受け入れ基準。状態は ⬜）
③ 失敗するテストを書く（Red）  → npm test で失敗を確認
④ 最小の実装で通す（Green）    → npm test が全部通る
⑤ 整理する（Refactor）         → npm test が通ったまま
⑥ npm run build → dist/transcribe.html をモックで手動確認
⑦ Windowsで実Azure（L1→L2）で確認（必要な改修のみ）
⑧ spec.md の状態と、下の変更履歴を更新
```
**どこを触るか迷ったら**：画面の見た目→`src/style.css`・`src/template.html`／文言→`errorMessages.js`／分割・送信・結合の流れ→`pipeline.js`／Azureとのやりとり→`azure.js`／設定→`config.sample.js`と`spec.md`6章。

## 2. 改修パターン別

### A. 分割の選択肢を変える（例：45分を追加）
- 触る：`src/app.js` の選択肢の配列 `[1, 5, 10, 15, 20, 30]`
- 仕様：`spec.md` 3章 F-04 の選択肢を更新
- テスト：不要（`planChunks` は任意の分に対応済み）。画面を手動確認
- 注意：`defaultChunkMinutes` は選択肢のどれかにする

### B. 設定項目を追加する（例：`timeoutSec`）
1. `config.sample.js` と `config.mock.js` に追加（コメントで意味を書く）
2. `spec.md` 6章の表に追加
3. 使う側（`azure.js` か `pipeline.js`）で `cfg.xxx` を読む。**未設定でも動く既定値**を持たせる（既存の config.js を壊さない）
4. テストの `cfg` にも追加

### C. エラー文言を追加・変更する
1. `spec.md` 7章の表に条件を追記
2. `tests/core.test.js` の「エラー文言」に期待を書く（Red）
3. `errorMessages.js` に分岐を追加（Green）。必ず「原因＋対処」

### D. 出力の形を変える（例：区間ごとに時刻の見出し）
1. 先にお客様へ確認（`spec.md` 10章）→ `spec.md` 5.5 を直す
2. `tests/core.test.js` の結合テストを書き換える（Red）
3. `src/core/joinResults.js` を直す。時刻が必要なら `pipeline.js` から区間情報を渡す
4. 画面と .txt は同じ文字列を使っているので、他の修正は不要

### E. 対応形式を増やす（例：FLAC）
1. `spec.md` 5.1 の表に方式を追記
2. 実ファイルで「切れるか」「Azureが受け取れるか」を確認（短い音声でL1）
3. `pipeline.js` の `openSource` に分岐を追加。WAVと同じ型（`totalSec`・`name`・`slice`）を返す
4. 切り出しの純粋な部分は `src/core/` に置いてテストを書く。`app.js` の `accept` に拡張子を追加
5. 切れない形式は、既存の「展開」に流すか、未対応メッセージ（C）にする

### F. Azure側を変える（API版・話者分離・言語）
- API版・言語：`config.js` の設定だけで足りる（コード変更なし）
- 話者分離などの追加パラメータ：`azure.js` の `definition` に追加。**応答の形が変わる**ので、`combinedPhrases` の取り出しとモックの応答（`mock/mock-server.js`）も合わせて直す
- 必ず公式ドキュメントで項目名を確認し、L1で実機確認

### G. 途中再開・失敗した区間だけやり直す
- 設計を先に決める：結果の保管先（メモリのみ／localStorage）、再開の操作（ボタンを増やす＝方針変更なので要確認）
- `pipeline.js` に「開始区間」と「既存の結果」を渡せるようにし、`transcribeFile` を拡張する
- テスト：途中で失敗→再開で残りだけ送られること（モックの `calls` で数える）

### H. 画面の見た目だけ変える
- `src/style.css`・`src/template.html` を直し、`npm run build` で確認
- ID（`#start`、`#result` など）を変える場合は `app.js` も同時に直す
- ライト・ダークの両方で見る。ボタン3つ・設定1つの方針は崩さない

### I. メモリや速度を改善する
- 先に**計測**する（Chrome／Edge の Shift+Esc でメモリ、3時間相当のファイルで観察）
- 変更後に同じ条件で再計測し、結果を `docs/` に残す
- 「区間を短くする」「展開を避ける」から先に検討。外部ライブラリの追加は最後

## 3. 完了の確認リスト
- [ ] `spec.md` を更新した（状態 ✅/⚠/⬜ が実態と合っている）
- [ ] 新しい振る舞いにテストがある。`npm test` が全部通る
- [ ] `npm run build` が成功し、`dist/transcribe.html` に本物のキーが入っていない
- [ ] モックで画面を手動確認した（ChromeとEdge）
- [ ] Azureに関わる変更は、実機でL1を確認した（できなければ⚠のまま報告）
- [ ] 下の変更履歴に1行書いた

## 4. 変更履歴
| 日付 | 内容 | 要件ID | 確認 |
|---|---|---|---|
| 2026-11-12 | 初版（L0のモックで検証。実Azure未確認） | 全般 | npm test 14件通過 |
