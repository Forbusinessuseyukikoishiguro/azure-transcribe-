# 要件ID と テストの対応（解説書12章より）
| ID | 要件 | テスト |
|---|---|---|
| F-03/F-04 | 分割・単位変更 | tests/core.test.js「分割計画」 |
| F-05 | 自動処理 | tests/pipeline.test.js「ボタン1回で…」 |
| F-06 | Azure Speech使用 | src/azure.js（L1で実機確認） |
| F-09 | 進捗・エラー | 再試行・エラー文言テスト |
| C-01/02 | キーはconfig.js | build.mjs（HTMLにキーを埋め込まない） |
| C-03/04 | 単一HTML＋config.js | npm run build |
| X-01/02 | モックで課金回避 | mock/mock-server.js（FAIL_RATEで429） |
| T-01〜03 | Chrome/Edge・低メモリ | **要実機確認** |
