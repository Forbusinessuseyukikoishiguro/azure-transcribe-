// 環境ごとに書き換えるのはこのファイルだけ（HTML本体は触らない）
window.APP_CONFIG = {
  speechEndpoint: "http://localhost:8787", // 接続先
  speechKey: "mock-key",   // 合言葉。他人に見せない・コミットしない
  apiVersion: "2024-11-15",          // ファスト・トランスクリプションのAPI版
  locale: "ja-JP",                   // 音声の言語
  defaultChunkMinutes: 10,           // 分割の初期値（分）
  maxChunkMB: 50,                    // 1区間の最大サイズ。超えたら自動で短くする
  maxRetries: 3,                     // 失敗時の再試行回数
  maxDecodeMB: 100                   // M4A等を展開する場合の最大ファイルサイズ
};
