/**
 * 【要点】src/ の複数ファイルを、1枚の HTML にまとめる。 (C-03/C-05)
 *   1. esbuild で src/app.js と import 先をすべて1つのJSにまとめる（外部ライブラリなし）
 *   2. template.html の目印を置き換える: CSSを <style> に、JSを <script> に埋め込む
 *   3. config.js は埋め込まず <script src="config.js"> で外から読む（キーを本体に入れない / C-01）
 *   4. dist/config.js が無いときだけ、モック向けの config.mock.js をコピーする
 * ★ minify:false にしてあるので、dist/transcribe.html の中でも変数名・関数名が読める。
 *   （esbuild はコメントを削るため、解説コメントは src/ 側を読む）
 */
import { build } from "esbuild";
import { readFileSync, writeFileSync, copyFileSync, mkdirSync, existsSync } from "node:fs";

mkdirSync("dist", { recursive: true });
const r = await build({ entryPoints: ["src/app.js"], bundle: true, minify: false, write: false, format: "iife", target: "es2020" });
const js = r.outputFiles[0].text.replace(/<\/script/gi, "<\\/script") // JS内の </script がHTMLを途中で閉じないよう無害化;
const html = readFileSync("src/template.html", "utf8")
  .replace("/*CSS*/", () => readFileSync("src/style.css", "utf8"))
  .replace("<!--CONFIG-->", '<script src="config.js"></script>')
  .replace("<!--APP-->", () => `<script>${js}</script>`);
writeFileSync("dist/transcribe.html", html);
if (!existsSync("dist/config.js")) copyFileSync("config.mock.js", "dist/config.js"); // 初期はモック向け
console.log("built dist/transcribe.html", (html.length / 1024).toFixed(1) + "KB");
